/**
 * computation/financeRenderer.js — Phase 3.5A Render Computation Isolation
 *
 * Isolated finance render computation.
 * Extracted from renderApp() in render.js.
 *
 * Owns:
 *   - Transaction HTML generation (txRows, expenseRows, examExpRows)
 *   - Finance summary statistics (incTuition, incExam, bStats …)
 *   - Module-local render cache (NOT window.__store.tabHtmlCache)
 *   - Explicit cache invalidation API
 *   - Lightweight render metrics
 *
 * KHÔNG:
 *   - Mutate DOM trực tiếp
 *   - Query Firestore
 *   - Gọi renderApp()
 *   - Implement virtualization
 *
 * Legacy bridge:
 *   render.js reads getFinanceSummary() / getFinanceCachedHtml() and still
 *   mirrors the results into window.__store.tabHtmlCache for backward compat.
 *
 * Row identity:
 *   Every <tr> carries a stable data-*-id attribute so future virtualization
 *   can key on it without re-scanning table structure.
 */

import { formatDate } from '../../../utils/format.js';

// ── Module-local branch-name helper (mirrors render.js _getBrN) ──────────────
const _getBrN = (br) =>
    (window.getBranchNameDisplay && window.getBranchNameDisplay(br))
        ? window.getBranchNameDisplay(br)
        : br;

// ── Module-local render cache ─────────────────────────────────────────────────
// Owned exclusively by this module. NOT shared via window.__store.tabHtmlCache.
const _cache = {
    txRows:       null,   // <tr data-tx-id>… string | null
    expenseRows:  null,   // <tr data-expense-id>… string | null
    examExpRows:  null,   // <tr data-exam-exp-id>… string | null
    /** @type {{ incTuition:number, incExam:number, incOther:number,
     *           incUniform:number, exp:number, expExamTotal:number,
     *           expUniform:number, txCount:number,
     *           bStats:Object, bExamStats:Object } | null} */
    summary:      null,
    paramsKey:    null,   // serialised params — duplicate-prevention
    dataVersion:  -1,     // mirrors window.__store._dataVersion at last compute
    _version:     0,      // increments on every invalidate()
};

// ── Metrics ───────────────────────────────────────────────────────────────────
const _metrics = {
    computations:        0,
    cacheHits:           0,
    duplicatePrevented:  0,
    skippedHiddenTab:    0,
    lastComputeMs:       0,
};

// ── Explicit invalidation ─────────────────────────────────────────────────────

/**
 * Invalidate a section of the finance render cache.
 * Call when underlying data changes (Firestore listener fire).
 *
 * @param {'txTable'|'expenseTable'|'examExpTable'|'summary'|'all'} section
 */
export function invalidateFinanceRender(section) {
    if (section === 'txTable'      || section === 'all') _cache.txRows      = null;
    if (section === 'expenseTable' || section === 'all') _cache.expenseRows = null;
    if (section === 'examExpTable' || section === 'all') _cache.examExpRows = null;
    if (section === 'summary'      || section === 'all') _cache.summary     = null;
    if (section === 'all') {
        _cache.paramsKey   = null;
        _cache.dataVersion = -1;
    }
    _cache._version++;
}

// ── Row renderers — stable data-*-id, reusable DOM boundary ──────────────────

/**
 * Render a single income/tuition transaction row.
 * Stable identity: data-tx-id="${tx.id}"
 *
 * @param {Object} tx       — transaction document from Firestore
 * @param {Object} opts
 * @param {boolean} opts.isSingleBranch
 * @param {boolean} opts.isAdmin
 * @param {string}  opts.branchTdHTML   — pre-built branch <td> or ''
 * @param {string}  opts.btnDel         — pre-built delete button or ''
 * @returns {string}
 */
export function renderTxRow(tx, opts = {}) {
    const { isSingleBranch = true, isAdmin = false, branchTdHTML = '', btnDel = '' } = opts;
    const isTuition  = tx.type === 'Học phí' || tx.type === 'Học phí + Lệ phí thi';
    const isExamType = tx.type === 'Lệ phí thi';
    const amtStr     = `+${(Number(tx.amount) || 0).toLocaleString()} ₫`;
    const typeBadge  = isTuition
        ? `<span class="badge bg-emerald-50 text-emerald-700 border border-emerald-200">Học phí</span>`
        : isExamType
            ? `<span class="badge bg-amber-50 text-amber-700 border border-amber-200">Thi đai</span>`
            : `<span class="badge bg-slate-50 text-slate-600 border border-slate-200">${tx.type || 'Khác'}</span>`;
    return `<tr data-tx-id="${tx.id || ''}"><td class="text-slate-500 text-[0.85rem]">${formatDate(tx.date)}</td>${branchTdHTML}<td class="font-bold text-slate-800 text-[0.9rem]">${tx.description || ''}</td><td>${typeBadge}</td><td class="text-emerald-600 font-bold">${amtStr}</td><td class="action-btns">${btnDel}</td></tr>`;
}

/**
 * Render a single expense row.
 * Stable identity: data-expense-id="${tx.id}"
 *
 * @param {Object} tx
 * @param {Object} opts
 * @param {boolean} opts.isSingleBranch
 * @param {boolean} opts.isAdmin
 * @param {string}  opts.branchTdHTML
 * @param {string}  opts.btnDel
 * @param {string}  opts.btnEditExp
 * @returns {string}
 */
export function renderExpenseRow(tx, opts = {}) {
    const { branchTdHTML = '', btnDel = '', btnEditExp = '' } = opts;
    return `<tr data-expense-id="${tx.id || ''}"><td>${formatDate(tx.date)}</td>${branchTdHTML}<td class="font-bold text-slate-800">${tx.description}</td><td class="text-rose-600 font-bold">-${(Number(tx.amount) || 0).toLocaleString()}</td><td class="action-btns">${btnEditExp}${btnDel}</td></tr>`;
}

/**
 * Render a single exam-expense row.
 * Stable identity: data-exam-exp-id="${tx.id}"
 *
 * @param {Object} tx
 * @param {Object} opts
 * @param {string}  opts.btnDel
 * @param {string}  opts.btnEditExp
 * @returns {string}
 */
export function renderExamExpRow(tx, opts = {}) {
    const { btnDel = '', btnEditExp = '' } = opts;
    return `<tr data-exam-exp-id="${tx.id || ''}"><td>${formatDate(tx.date)}</td><td class="font-bold text-slate-800">${tx.description}</td><td class="text-rose-600 font-bold">-${(Number(tx.amount) || 0).toLocaleString()}</td><td class="action-btns">${btnEditExp}${btnDel}</td></tr>`;
}

// ── Core computation ──────────────────────────────────────────────────────────

/**
 * Single-pass finance computation.
 * Computes summary statistics AND (only for the current tab) builds row HTML.
 *
 * Called by renderApp() instead of the inline transaction forEach loop.
 *
 * @param {Array}  transactions — allTransactions from store
 * @param {Object} params
 * @param {string}   params.curTabId       — active tab ('tx'|'expense'|'exam'|…)
 * @param {string}   params.selBranch      — branch filter value
 * @param {string}   params.search         — search text (lower-cased)
 * @param {boolean}  params.isSingleBranch
 * @param {boolean}  params.isAdmin
 * @param {string[]} params.invCats        — inventory category names
 * @param {number}   params.bCount         — number of branches
 */
export function computeAndCacheFinance(transactions, params) {
    const {
        curTabId      = 'tx',
        selBranch     = 'all',
        search        = '',
        isSingleBranch = true,
        isAdmin       = false,
        invCats       = [],
        bCount        = 1,
    } = params;

    // ── Cache-hit detection ──
    const paramsKey    = `${curTabId}|${selBranch}|${search}`;
    const dataVersion  = (window.__store || {})._dataVersion || 0;
    if (
        _cache.summary !== null &&
        _cache.paramsKey   === paramsKey &&
        _cache.dataVersion === dataVersion
    ) {
        _metrics.cacheHits++;
        return;
    }

    const t0 = performance.now();
    _metrics.computations++;

    // ── Init summary accumulators ──
    let incTuition = 0, incExam = 0, incOther = 0, incUniform = 0;
    let exp = 0, expExamTotal = 0, expUniform = 0;
    let txCount = 0;

    const bStats = {}, bExamStats = {};
    for (let bi = 1; bi <= bCount; bi++) {
        bStats['CS' + bi]     = { income: 0, active: 0, debt: 0, tuitionMap: {}, examFeeMap: {} };
        bExamStats['CS' + bi] = 0;
    }

    // ── Decide which row HTML sections to build (hidden-tab skip) ──
    const buildTxRows      = curTabId === 'tx';
    const buildExpRows     = curTabId === 'expense';
    const buildExamExpRows = curTabId === 'exam';

    if (!buildTxRows && !buildExpRows && !buildExamExpRows) {
        _metrics.skippedHiddenTab++;
    }

    let txRows = buildTxRows      ? '' : null;
    let expenseRows = buildExpRows ? '' : null;
    let examExpRows = buildExamExpRows ? '' : null;

    // ── Single pass — mirrors renderApp() lines 249-324 exactly ──
    transactions.forEach(t => {
        const cleanName    = t.description ? t.description.trim() : '';
        const isUniformTx  = invCats.some(cat =>
            t.type === `Thu ${cat}` || t.type === `Chi ${cat}` || t.type === `Tặng ${cat}`
        ) || t.type === 'Võ phục';

        let isBranchMatch = true;
        if (!isSingleBranch && selBranch !== 'all' && t.branch !== selBranch && t.branch !== 'Chung') {
            isBranchMatch = false;
        }
        let isSearchMatch = true;
        if (search && !cleanName.toLowerCase().includes(search) && !(t.examTitle || '').toLowerCase().includes(search)) {
            isSearchMatch = false;
        }

        const safeBranch   = t.branch || 'CS1';
        const safeNameEsc  = cleanName.replace(/'/g, "\\'");
        const branchTdHTML = isSingleBranch
            ? ''
            : `<td class="col-branch"><span class="badge bg-slate-100 text-slate-600 border border-slate-200">${_getBrN(safeBranch)}</span></td>`;
        const btnDel = isAdmin
            ? `<button type="button" class="btn-sm bg-rose-50 text-rose-600 hover:bg-rose-500 hover:text-white ml-1" onclick="deleteTx('${t.id}', '${t.relatedInvId || ''}')">🗑</button>`
            : '';

        if (isUniformTx) {
            const isInc  = invCats.some(cat => t.type === `Thu ${cat}`) || t.type === 'Võ phục';
            const isGift = invCats.some(cat => t.type === `Tặng ${cat}`);
            if (isInc)        incUniform  += Number(t.amount) || 0;
            else if (!isGift) expUniform  += Number(t.amount) || 0;
            return;
        }
        if (!isBranchMatch || !isSearchMatch) return;

        const btnEditExp = isAdmin
            ? `<button type="button" class="btn-sm bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white" onclick="openEditExpense('${t.id}')">✏️</button>`
            : '';

        if (t.type === 'Chi phí') {
            exp += Number(t.amount) || 0;
            if (buildExpRows) {
                expenseRows += renderExpenseRow(t, { branchTdHTML, btnDel, btnEditExp });
            }
        } else if (t.type === 'Chi phí kỳ thi') {
            expExamTotal += Number(t.amount) || 0;
            if (buildExamExpRows) {
                examExpRows += renderExamExpRow(t, { btnDel, btnEditExp });
            }
        } else {
            txCount++;
            let allocatedAmount = Number(t.amount) || 0;

            if (t.type === 'Học phí') {
                allocatedAmount = t.packageMonths
                    ? allocatedAmount / t.packageMonths.length
                    : allocatedAmount;
                incTuition += allocatedAmount;
            } else if (t.type === 'Học phí + Lệ phí thi') {
                allocatedAmount = t.packageMonths
                    ? (Number(t.tuitionAmount) || 0) / t.packageMonths.length
                    : (Number(t.tuitionAmount) || 0);
                incTuition += allocatedAmount;
                incExam    += Number(t.examAmount) || 0;
            } else if (t.type === 'Lệ phí thi') {
                incExam += allocatedAmount;
            } else {
                incOther += allocatedAmount;
            }

            // Branch stats (income + fee maps)
            const _txBr = t.branch || 'CS1';
            if (bStats[_txBr] !== undefined) {
                const _examPart = (t.type === 'Học phí + Lệ phí thi')
                    ? (Number(t.examAmount) || 0)
                    : 0;
                bStats[_txBr].income += allocatedAmount + _examPart;

                if (t.type === 'Lệ phí thi') {
                    const _ek = Math.round(allocatedAmount);
                    if (_ek > 0) bStats[_txBr].examFeeMap[_ek] = (bStats[_txBr].examFeeMap[_ek] || 0) + 1;
                } else if (t.type === 'Học phí + Lệ phí thi') {
                    const _ek2 = Math.round(Number(t.examAmount) || 0);
                    if (_ek2 > 0) bStats[_txBr].examFeeMap[_ek2] = (bStats[_txBr].examFeeMap[_ek2] || 0) + 1;
                }
                if (t.type === 'Học phí' || t.type === 'Học phí + Lệ phí thi') {
                    const _tf = Math.round(Number(
                        t.type === 'Học phí + Lệ phí thi' ? t.tuitionAmount : t.amount
                    ) || 0);
                    if (_tf > 0) bStats[_txBr].tuitionMap[_tf] = (bStats[_txBr].tuitionMap[_tf] || 0) + 1;
                }
            }

            // Build tx row (current tab only)
            if (buildTxRows && isBranchMatch) {
                txRows += renderTxRow(t, { isSingleBranch, isAdmin, branchTdHTML, btnDel });
            }
        }
    });

    // ── Store results in module-local cache ──
    if (buildTxRows)      _cache.txRows      = txRows;
    if (buildExpRows)     _cache.expenseRows = expenseRows;
    if (buildExamExpRows) _cache.examExpRows = examExpRows;

    _cache.summary = {
        incTuition, incExam, incOther, incUniform,
        exp, expExamTotal, expUniform, txCount,
        bStats, bExamStats,
    };
    _cache.paramsKey   = paramsKey;
    _cache.dataVersion = dataVersion;

    // ── Metrics ──
    const ms = performance.now() - t0;
    _metrics.lastComputeMs = ms;
    if (ms > 16) {
        console.warn(`[financeRenderer] 🐢 Slow computation: ${ms.toFixed(1)}ms (${transactions.length} transactions)`);
    }

    // ── [Phase 3.8A] Large list safety — track tx.txList row count ────────────
    // Virtualization-ready boundary: tx.txList là isolated render boundary.
    // Khi txCount > 500 → console.warn để chuẩn bị virtual rendering.
    // KHÔNG block render, KHÔNG thay đổi output.
    //   START: tx.txList  → vị trí bắt đầu render transaction rows
    //   END:   tx.txList  → cuối txRows HTML (hoặc load-more button)
    if (typeof window.trackLargeListRender === 'function') {
        if (buildTxRows) {
            window.trackLargeListRender('tx.txList', txCount, { reason: 'render-tx-list' });
        }
    }
}

// ── Public read API ───────────────────────────────────────────────────────────

/**
 * Return cached HTML for a finance list section.
 *
 * @param {'txRows'|'expenseRows'|'examExpRows'} section
 * @returns {string}
 */
export function getFinanceCachedHtml(section) {
    return _cache[section] || '';
}

/**
 * Return the cached finance summary (stats for current month/filter).
 * Returns null before first computation.
 *
 * @returns {{ incTuition:number, incExam:number, incOther:number,
 *             incUniform:number, exp:number, expExamTotal:number,
 *             expUniform:number, txCount:number,
 *             bStats:Object, bExamStats:Object } | null}
 */
export function getFinanceSummary() {
    return _cache.summary;
}

/**
 * Return lightweight render performance metrics for dev diagnostics.
 *
 * @returns {{ computations:number, cacheHits:number, duplicatePrevented:number,
 *             skippedHiddenTab:number, lastComputeMs:number }}
 */
export function getFinanceMetrics() {
    return { ..._metrics };
}
